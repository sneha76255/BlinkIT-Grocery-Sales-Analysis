BLINKIT GROCERY SALES ANALYSIS — SUBMISSION PACK
Company/Brief: Sapphire IQ
Domain: Retail & Grocery Sales Analytics

FILES
1. BlinkIT_Grocery_Analysis_Submission.xlsx
   Executive Dashboard, Original Data, Cleaned Data, Sales by Item Type,
   Outlet Performance, Location Analysis, Fat Content Analysis,
   Outlet Type Analysis, Outlet Size Analysis, Data Quality.
2. BlinkIT_Grocery_Sales_Analysis.ipynb
   Python workflow for loading, cleaning, exploring, visualizing and exporting data.
3. BlinkIT_Grocery_Analysis_Report.pdf
   Project summary, data quality notes, key metrics, recommendations and limitations.

IMPORTANT
Original data is preserved. Fat Content labels are standardized in the cleaned dataset.
Missing Item Weight values are imputed using Item Type median, with overall median fallback.
No exact duplicate rows were detected. Snapshot data does not support time-series or profit analysis.

SUBMISSION
Upload the Excel, Notebook and PDF to your internship portal if multiple files are allowed.
If only one URL is accepted, upload these files to one GitHub repository or Google Drive folder
and submit the share/repository URL. Do not submit a local computer path.
